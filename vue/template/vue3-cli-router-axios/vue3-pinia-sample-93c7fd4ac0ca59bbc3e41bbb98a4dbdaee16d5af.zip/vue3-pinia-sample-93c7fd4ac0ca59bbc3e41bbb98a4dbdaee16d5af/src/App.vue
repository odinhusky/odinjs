<template>
  <router-view/>
</template>

<style lang="scss">
@import "~bootstrap";
</style>
